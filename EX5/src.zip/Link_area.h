#pragma once
#ifndef LINK_AREA
#define LINK_AREA
#include"CImg.h"
#include<iostream>
#include <string>
#include<vector>
#include<opencv.hpp>
#define T_max 400
#define T_min 10
using namespace cv;
using namespace std;
using namespace cimg_library;
struct  Area_point
{
	int x;
	int y;
	int label;
	Area_point(int x_, int y_, int label_)
	{
		x = x_;
		y = y_;
		label = label_;
	}
};
class Link_area {
private:
	CImg<unsigned char> Src;
	CImg<unsigned char> result;
	CImg<unsigned char> scal;
	string save_path;
	int label;
	vector<Area_point>temp;
	vector<vector<Area_point>>link_area;
	vector<vector<Area_point>>Scaleplate;
	int Scaleplate_left;
	int Scaleplate_right;
public:
	Link_area(CImg<unsigned char> input, string save_path);
	void get_Link_Area();
	void filtrate();
	void Draw_square();
	void get_Scaleplate(string save_path);
	void get_Top_Number(string save_path);
	void get_Bottom_Number(int min_height, int max_height, int left, int right, string save_path);
	void get_blocks(int threshold,int type,double left_scale,double right_scale);
};

#endif