#pragma once
#ifndef DELATE_H
#define DELATE_H
#include "CImg.h"
#include<iostream>
#include <string>
using namespace std;
using namespace cimg_library;
class Delate {
private:
	CImg<unsigned char> Src;
	CImg<unsigned char> result;
	string save_path;
public:
	Delate(CImg<unsigned char> input, string save_path);
	void Do_delate();
};



#endif