#include"otsu.h"
#include"CImg.h"
#include"Delate.h"
#include"Link_area.h"
#include"number_recognition.h"
#include<iostream>
using namespace std;
class Test {
private:
	string Src_name;
	string otsu_name;
	string delate_name;
	string link_area_name;
	string top_number_name;
	string bottom_number_name;
	string Scaleplate_name;
	CImg<unsigned char>img;
	int bottom_left;
	int bottom_right;
	int bottom_top;
	int bottom_down;
	int threshold;
	int type;
	double left_scale;
	double right_scale;
public:
	Test(string file, string src_name)
	{
		this->Src_name = file +'/'+ src_name;
		this->otsu_name = file + '/' + "otsu.bmp";
		this->delate_name = file + '/' + "delate.bmp";
		this->Scaleplate_name = file + '/' + "Scaleplate.bmp";
		this->top_number_name = file + '/' + "top_number.bmp";
		this->bottom_number_name = file + '/' + "bottom_number.bmp";
		this->link_area_name = file + '/' + "link_area.bmp";
		img.load_bmp(Src_name.c_str());
	}
	void Do_Operate(int left, int right, int top, int bottom, int thres, int typ, double s_l, double s_r)
	{
		otsu Otsu(img, otsu_name.c_str());
		Otsu.seg();
		img.load_bmp(otsu_name.c_str());
		Delate delate(img, delate_name.c_str());
		delate.Do_delate();
		img.load_bmp(delate_name.c_str());
		Link_area link(img, link_area_name.c_str());
		link.get_Link_Area();
		link.filtrate();
		link.get_Top_Number(top_number_name.c_str());
		//link.get_Bottom_Number(top,bottom,left,right,bottom_number_name.c_str());
		link.get_Scaleplate(Scaleplate_name.c_str());
		Number_Detect detect_scale(Scaleplate_name.c_str(), "");
		detect_scale.getBottomNumber();
		Number_Detect detect_top(top_number_name.c_str(),"");
		detect_top.getTopNumber();
		Number_Detect detect_bottom(bottom_number_name.c_str(), "");
		detect_bottom.getBottomNumber();
		link.get_blocks(thres, typ, s_l, s_r);
	}
};


int main() {
	Test t1("C:/Users/HP/Desktop/HW5", "H-Image0.bmp");
	t1.Do_Operate(1427, 1994, 1458, 1500,3, 1, 5.85, 0.55);
	Test t2("C:/Users/HP/Desktop/HW5", "H-Image1.bmp");
	t2.Do_Operate(-1, -1, -1, -1, 0.3, 2, 9.75, -0.2);
	Test t3("C:/Users/HP/Desktop/HW5", "H-Image2.bmp");
	t3.Do_Operate(-1, -1, -1, -1, 3, 3, 7.95, -0.15);
	//CImg<unsigned char>img;
	//img.load_bmp("C:/Users/HP/Desktop/HW5/H-Image2.bmp");
	//otsu test(img, "C:/Users/HP/Desktop/HW5/otsu.bmp");
	//test.seg();
	//img.load_bmp("C:/Users/HP/Desktop/HW5/otsu.bmp");
	//Delate test1(img,"C:/Users/HP/Desktop/HW5/delate.bmp");
	//test1.Do_delate();
	//img.load_bmp("C:/Users/HP/Desktop/HW5/delate.bmp");
	//Link_area test2(img, "C:/Users/HP/Desktop/HW5/link_area.bmp");
	//test2.get_Link_Area();
	//test2.filtrate();
	//test2.Draw_square();
	//test2.get_Top_Number("C:/Users/HP/Desktop/HW5/top_number.bmp");
	//test2.get_Bottom_Number(1440,1500,180,235,"C:/Users/HP/Desktop/HW5/bottom_number.bmp");
	//test2.get_Bottom_Number(1458, 1500,1427,1994,"C:/Users/HP/Desktop/HW5/bottom_number.bmp");
	//test2.get_Scaleplate("C:/Users/HP/Desktop/HW5/Scaleplate.bmp");
	//Number_Detect test3 = Number_Detect("C:/Users/HP/Desktop/HW5/bottom_number.bmp", "C:/Users/HP/Desktop/HW5/result.bmp");
	//Number_Detect test4 = Number_Detect("C:/Users/HP/Desktop/HW5/bottom_number.bmp", "C:/Users/HP/Desktop/HW5/result.bmp");
	//test3.getTopNumber();
	//test3.getBottomNumber();
	//test2.get_blocks(3, 1,5.85,0.55);
	//test2.get_blocks(0.3, 2, 9.75, -0.2);
	//test2.get_blocks(3, 3, 7.95, -0.15);
	return 0;
}