#pragma once
#ifndef NUMBER_RECOGNITION
#define NUMBER_RECOGNITION
#include<iostream>
#include <string>
#include<vector>
#include <opencv2/opencv.hpp>
#include <opencv2/imgproc/imgproc.hpp>
using namespace cv;
using namespace std;

class Number_Detect {
private:
	Mat Src;
	Mat Dst;
public:
	Number_Detect(string input_path, string save_path);
	void get_Number();
};

#endif