#pragma once
#ifndef LINK_AREA
#define LINK_AREA
#include"CImg.h"
#include<iostream>
#include <string>
#include<vector>
#include<opencv.hpp>
#define T_max 200
#define T_min 50
using namespace cv;
using namespace std;
using namespace cimg_library;
struct  Area_point
{
	int x;
	int y;
	int label;
	Area_point(int x_, int y_, int label_)
	{
		x = x_;
		y = y_;
		label = label_;
	}
};
class Link_area {
private:
	CImg<unsigned char> Src;
	CImg<unsigned char> result;
	CImg<unsigned char> scal;
	string save_path;
	int label;
	vector<Area_point>temp;
	vector<vector<Area_point>>link_area;
	vector<vector<Area_point>>Scaleplate;
public:
	Link_area(CImg<unsigned char> input, string save_path);
	void get_Link_Area();
	void filtrate();
	void Draw_square();
	void get_Scaleplate(string save_path);
};



#endif