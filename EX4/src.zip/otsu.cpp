#include "otsu.h"

otsu::otsu(CImg<unsigned char> input,string save_path)
{
	this->save_path = save_path;
	this->Src = CImg<unsigned char>(input._width, input._height, 1, 3);
	Gray = CImg<unsigned char>(input._width, input._height, 1, 1);
	cimg_forXY(input, x, y) {
		Src(x, y, 0) = input(x, y, 0);
		Src(x, y, 1) = input(x, y, 1);
		Src(x, y, 2) = input(x, y, 2);
	}
	for (int i = 0; i < 256; i++) {
		gray_level[i] = 0;
	}
}

void otsu::getGray()
{
	cimg_forXY(Src, x, y) {
		Gray(x, y) = 0.299 * Src(x, y, 0) + 0.587 * Src(x, y, 1) + 0.114 * Src(x, y, 2);
		int col = Gray(x, y);
		gray_level[col] ++;//�Ҷ�ֱ��ͼ
	}

}

void otsu::findThreshold()
{
	double max_g = 0;
	int best_t = 0;
	for (int i = 0; i < 256; i++) {
		double w0 = 0;
		double w1 = 0;
		double u0 = 0;
		double u1 = 0;
		for (int j = 0; j < 256; j++) {
			if (j < i) {
				w1 += gray_level[j];
				u1 += gray_level[j] * j;
			}//�����ĻҶ�ƽ��ֵ�ͱ���������
			else {
				w0 += gray_level[j];
				u0 += gray_level[j] * j;
			}//ǰ���ĻҶ�ƽ��ֵ��ǰ��������
		}
		int total = Gray._width * Gray._height;
		if (w1 != 0)
			u1 = u1 / w1;
		if (w0 != 0)
			u0 = u0 / w0;
		w1 = w1 / total;//����ǰ�󾰵����
		w0 = w0 / total;
		double g = w0 * w1 * pow((u0 - u1), 2);
		if (g > max_g) {
			max_g = g;
			best_t = i;
		}
	}
	threshold = best_t;
}

void otsu::seg()
{
	getGray();
	findThreshold();
	cimg_forXY(Gray, x, y) {
		if (Gray(x, y) > threshold) {
			Gray(x, y) = 255;
		}
		else {
			Gray(x, y) = 0;
		}
	}
	Gray.display();
	Gray.save(save_path.c_str());
}
