#pragma once
#ifndef OTSU_H
#define OTSU_H
#include "CImg.h"
#include <string>
using namespace std;
using namespace cimg_library;
class otsu {
private:
	CImg<unsigned char> Src;
	CImg<unsigned char> Gray;
	int threshold;
	int gray_level[256];
	string save_path;
public:
	otsu(CImg<unsigned char> input,string save_path);
	void getGray();
	void findThreshold();
	void seg();
};


#endif