#include "Delate.h"

Delate::Delate(CImg<unsigned char> input,string save_path)
{
	this->save_path = save_path;
	int count = 0;
	this->Src = CImg<unsigned char>(input._width, input._height, 1, 1);
	this->result = CImg<unsigned char>(input._width, input._height, 1, 1);
	cout << input._width << " " << input._height << endl;
	cimg_forXY(input, x, y) {
		Src(x, y) = input(x, y);
		result(x, y) = 255;		
	}
}

void Delate::Do_delate()
{
	cimg_forXY(Src, x, y) {
		if (x == 0 && y >= 1 && (Src(x, y) == 0 || Src(x, y - 1) == 0))//��һ��
		{
			result(x, y) = 0;
		}
		if (x >= 1 && y >= 1 && (Src(x, y) == 0 || Src(x - 1, y) == 0 || Src(x, y - 1) == 0))
		{
			result(x, y) = 0;
		}
		if (y == 0 && x >= 1 && (Src(x, y) == 0 || Src(x - 1, y) == 0))//��һ��
		{
			result(x, y) = 0;
		}
	}
	result.display();
	result.save(save_path.c_str());
}
