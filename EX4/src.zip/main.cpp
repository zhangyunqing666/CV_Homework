#include"otsu.h"
#include"CImg.h"
#include"Delate.h"
#include"Link_area.h"
#include"number_recognition.h"
#include<iostream>
using namespace std;
int main() {
	CImg<unsigned char>img;
	img.load_bmp("C:/Users/HP/Desktop/H-Image.bmp");
	otsu test(img, "C:/Users/HP/Desktop/otsu.bmp");
	test.seg();
	img.load_bmp("C:/Users/HP/Desktop/otsu.bmp");
	Delate test1(img,"C:/Users/HP/Desktop/delate.bmp");
	test1.Do_delate();
	img.load_bmp("C:/Users/HP/Desktop/delate.bmp");
	Link_area test2(img, "C:/Users/HP/Desktop/link_area.bmp");
	test2.get_Link_Area();
	test2.filtrate();
	test2.Draw_square();
	test2.get_Scaleplate("C:/Users/HP/Desktop/Scaleplate.bmp");
	Number_Detect test3 = Number_Detect("C:/Users/HP/Desktop/Scaleplate.bmp", "C:/Users/HP/Desktop/result.bmp");
	test3.get_Number();
	return 0;
}