#pragma once
#include"Link_area.h"
#include<queue>

Link_area::Link_area(CImg<unsigned char> input, string save_path)
{
	this->save_path = save_path;
	this->result = CImg<unsigned char>(input._width, input._height, 1 , 3);
	this->Src = CImg<unsigned char>(input._width, input._height, 1, 1);
	this->label = 0;
	cimg_forXY(input, x, y) {
		Src(x, y) = input(x, y);
		result(x, y, 0) = input(x, y);
		result(x, y, 1) = input(x, y);
		result(x, y, 2) = input(x, y);
	}
	
}

void Link_area::get_Link_Area()
{
	cimg_forXY(Src, x, y) {
		if (Src(x, y) == 0)//�ҵ���һ�����ӵ�
		{
			temp.clear();
			label++;
			Area_point base(x, y, label);//���ӵ�
			Src(x, y) = 255;//�����ӵ����ظ�Ϊ����
			temp.push_back(base);
			queue<Area_point> p;
			p.push(base);
			while (!p.empty())
			{
				if (p.front().x >= 1 && p.front().y >= 1 && p.front().x < Src.width() - 1 && p.front().y < Src.height() - 1)
				{
					for (int i = -1; i < 2; i++)//�����˸�����
					{
						for (int j = -1; j < 2; j++)
						{
							if (Src(p.front().x + i, p.front().y + j) == 0)//�����ͨ�ͼ������
							{
								p.push(Area_point(p.front().x + i, p.front().y + j, label));
								Src(p.front().x + i, p.front().y + j) = 255;
								temp.push_back(Area_point(p.front().x + i, p.front().y + j, label));
							}
						}
					}//�˸��������
				}
				p.pop();
			}
			link_area.push_back(temp);//���һ����ͨ��
		}
	}
	//cout << link_area.size();
}

void Link_area::filtrate()
{
	vector<vector<Area_point>>temp;
	for (int i = 0; i < link_area.size(); i++)
	{
		if (link_area[i].size() < T_max && link_area[i].size()> T_min)
			temp.push_back(link_area[i]);
		if (link_area[i].size() >= 5500 && link_area[i].size() < 7000)
			Scaleplate.push_back(link_area[i]);
	}
	cout << temp.size() << endl;
	link_area.clear();
	link_area = temp;
}

vector<Area_point> get_diagonal(vector<Area_point>area)
{
	int x_min = area[0].x;
	int x_max = 0;
	int y_min = area[0].y;
	int y_max = 0;
	for (int i = 0; i < area.size(); i++)
	{
		if (area[i].x > x_max)
			x_max = area[i].x;
		if (area[i].x < x_min)
			x_min = area[i].x;
		if (area[i].y > y_max)
			y_max = area[i].y;
		if (area[i].y < y_min)
			y_min = area[i].y;
	}
	vector<Area_point>temp;
	temp.push_back(Area_point(x_min, y_min, 0));
	temp.push_back(Area_point(x_max, y_max, 0));
	return temp;
}

void Link_area::Draw_square()
{
	unsigned char red[3] = { 255, 0, 0 };
	for (int i = 0; i < link_area.size(); i++)
	{
		vector<Area_point>temp = get_diagonal(link_area[i]);
		result.draw_rectangle(temp[0].x - 3, temp[0].y - 3, temp[1].x + 3, temp[1].y + 3, red,1, ~0U);
	}
	result.display();
}

void Link_area::get_Scaleplate(string save_path)
{
	unsigned char blue[3] = { 0, 0, 255 };
	vector<Area_point>scaleplate = get_diagonal(Scaleplate[1]);
	result.draw_rectangle(scaleplate[0].x - 10, scaleplate[0].y - 35, scaleplate[1].x + 10, scaleplate[1].y + 35, blue, 1, ~0U);
	result.display();
	result.save(this->save_path.c_str());
	scal = CImg<unsigned char>(scaleplate[1].x - scaleplate[0].x - 100 , scaleplate[1].y - scaleplate[0].y + 10, 1, 1);
	cimg_forXY(scal, x, y)
	{
		scal(x, y) = result(scaleplate[0].x - 5 + x, scaleplate[0].y + y + 20);
	}
	scal.display();
	int wid = scal._width;
	int hei = scal._height;
	scal.save(save_path.c_str());
}
