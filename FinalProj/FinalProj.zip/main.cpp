#include "Hough.h"
#include "CANNY.h"
#include"CutImage.h"
#include<sstream>
class Operate {
private:
	string rotate_save_path;
	string cut_save_path;
	vector<std::string> files;
	void getFiles(const std::string & path, std::vector<std::string> & files)
	{
		//�ļ����  
		long long hFile = 0;
		//�ļ���Ϣ��_finddata_t��Ҫio.hͷ�ļ�  
		struct _finddata_t fileinfo;
		std::string p;
		int i = 0;
		if ((hFile = _findfirst(p.assign(path).append("\\*").c_str(), &fileinfo)) != -1)
		{
			do
			{
				//�����Ŀ¼,����֮  
				//�������,�����б�  
				if ((fileinfo.attrib & _A_SUBDIR))
				{
					//if (strcmp(fileinfo.name, ".") != 0 && strcmp(fileinfo.name, "..") != 0)
						//getFiles(p.assign(path).append("\\").append(fileinfo.name), files);
				}
				else
				{
					files.push_back(p.assign(path).append("/").append(fileinfo.name));
				}
			} while (_findnext(hFile, &fileinfo) == 0);
			_findclose(hFile);
		}
	}
public:
	Operate(string folder)
	{
		rotate_save_path = folder + "/rotate/";
		cut_save_path = folder + "/cut/";
		getFiles(folder, files);
	}
	void do_operate()
	{
		for (int i = 0; i < files.size(); i++)
		{
			cout << i << endl;
			stringstream ss;
			string img_num;
			ss << i;
			ss >> img_num;
			string r_path = rotate_save_path + img_num + ".bmp";
			string c_path = cut_save_path + img_num + ".bmp";
			CutImage test(files[i], r_path, c_path);
			test.getImg();
			test.Rotate();
			test.Cut();
		}
	}
};

int main() {
	Operate test("C:/Users/HP/Desktop/DataSet");
	test.do_operate();
	return 0;
}