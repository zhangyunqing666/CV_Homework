#include"CutImage.h"
#include<cmath>
#define PI acos(-1)

void CutImage::Otsu()
{
	getGray();
	findThreshold();
	cimg_forXY(otsu, x, y) {
		if (otsu(x, y) > threshold) {
			otsu(x, y) = 255;
		}
		else {
			otsu(x, y) = 0;
		}
	}
	//otsu.display();
}
void CutImage::Delate()
{
	cimg_forXY(otsu, x, y) {
		if (x == 0 && y >= 1 && (otsu(x, y) == 0 || otsu(x, y - 1) == 0))//��һ��
		{
			delate(x, y) = 0;
		}
		if (x >= 1 && y >= 1 && (otsu(x, y) == 0 || otsu(x - 1, y) == 0 || otsu(x, y - 1) == 0))
		{
			delate(x, y) = 0;
		}
		if (y == 0 && x >= 1 && (otsu(x, y) == 0 || otsu(x - 1, y) == 0))//��һ��
		{
			delate(x, y) = 0;
		}
	}
	//delate.display();
}
void CutImage::get_link_area()
{
	CImg<unsigned char> delate_temp = CImg<unsigned char>(delate._width, delate._height, 1, 1);
	cimg_forXY(delate_temp, x, y)
	{
		delate_temp(x, y) = delate(x, y);
	}

	cimg_forXY(delate_temp, x, y) {
		if (delate_temp(x, y) == 0)//�ҵ���һ�����ӵ�
		{
			temp.clear();
			Area_point base(x, y);//���ӵ�
			delate_temp(x, y) = 255;//�����ӵ����ظ�Ϊ����
			temp.push_back(base);
			queue<Area_point> p;
			p.push(base);
			while (!p.empty())
			{
				if (p.front().x >= 1 && p.front().y >= 1 && p.front().x < delate_temp.width() - 1 && p.front().y < delate_temp.height() - 1)
				{
					for (int i = -1; i < 2; i++)//�����˸�����
					{
						for (int j = -1; j < 2; j++)
						{
							if (delate_temp(p.front().x + i, p.front().y + j) == 0)//�����ͨ�ͼ������
							{
								p.push(Area_point(p.front().x + i, p.front().y + j));
								delate_temp(p.front().x + i, p.front().y + j) = 255;
								temp.push_back(Area_point(p.front().x + i, p.front().y + j));
							}
						}
					}//�˸��������
				}
				p.pop();
			}
			if(temp.size()>100)
				link_area.push_back(temp);//���һ����ͨ��
		}
	}
}
void CutImage::getGray()
{
	for (int i = 0; i < 256; i++) {
		gray_level[i] = 0;
	}
	cimg_forXY(rotate, x, y) {
		otsu(x, y) = 0.299 * rotate(x, y, 0) + 0.587 * rotate(x, y, 1) + 0.114 * rotate(x, y, 2);
		//delate(x, y) = otsu(x, y);
		int col = otsu(x, y);
		gray_level[col] ++;//�Ҷ�ֱ��ͼ
	}
}
void CutImage::findThreshold()
{
	double max_g = 0;
	int best_t = 0;
	for (int i = 0; i < 256; i++) {
		double w0 = 0;
		double w1 = 0;
		double u0 = 0;
		double u1 = 0;
		for (int j = 0; j < 256; j++) {
			if (j < i) {
				w1 += gray_level[j];
				u1 += gray_level[j] * j;
			}//�����ĻҶ�ƽ��ֵ�ͱ���������
			else {
				w0 += gray_level[j];
				u0 += gray_level[j] * j;
			}//ǰ���ĻҶ�ƽ��ֵ��ǰ��������
		}
		int total = otsu._width * otsu._height;
		if (w1 != 0)
			u1 = u1 / w1;
		if (w0 != 0)
			u0 = u0 / w0;
		w1 = w1 / total;//����ǰ�󾰵����
		w0 = w0 / total;
		double g = w0 * w1 * pow((u0 - u1), 2);
		if (g > max_g) {
			max_g = g;
			best_t = i;
		}
	}
	threshold = best_t;
}

CutImage::CutImage(string file, string rotate_card_save_path, string cut_card_save_path)
{
	this->filename = file;
	this->cut_save_path = cut_card_save_path;
	this->rotate_save_path = rotate_card_save_path;
}

void CutImage::getImg()
{
	Hough hough(filename.c_str(), 1);
	this->Src = hough.I4;
	hough.filter_corss_point();
	this->corss_point = hough.corss_point;
}

bool cmp1(pair<int,int> a, pair<int, int> b)
{
	return a.first + a.second < b.first + b.second;
}
bool cmp2(pair<int, int> a, pair<int, int> b)
{
	return a.first - a.second < b.first - b.second;
}

void CutImage::Rotate()
{
	vector<pair<int, int>>sorted1 = corss_point;
	sort(sorted1.begin(), sorted1.end(), cmp1);
	pair<int, int>left_top = sorted1[0];
	pair<int, int>right_bottom = sorted1[sorted1.size() - 1];
	vector<pair<int, int>>sorted2 = corss_point;
	sort(sorted2.begin(), sorted2.end(), cmp2);
	pair<int, int>left_bottom = sorted2[0];
	pair<int, int>right_top = sorted2[sorted2.size() - 1];

	rotate = Src;
	//rotate.display();
	rotate.save("test.bmp");
	Mat src = imread("test.bmp");

	//͸�ӱ任ǰ���ĸ����������꣬+5��Ϊ�˷�ֱֹ�߷������µĽǵ�ƫ��
	vector<Point2f> src_corner(4);
	src_corner[0].x = left_top.first+5;
	src_corner[0].y = left_top.second+5;
	src_corner[1].x = right_top.first-5;
	src_corner[1].y = right_top.second+5;
	src_corner[2].x = right_bottom.first-5;
	src_corner[2].y = right_bottom.second-5;
	src_corner[3].x = left_bottom.first+5;
	src_corner[3].y = left_bottom.second-5;

		//͸�ӱ任����ĸ�����������
	Mat resultImg(800, 1600, CV_8UC3);
	vector<Point2f> dst_corner(4);
	dst_corner[0] = Point(0, 0);
	dst_corner[1] = Point(resultImg.cols, 0);
	dst_corner[2] = Point(resultImg.cols, resultImg.rows);
	dst_corner[3] = Point(0, resultImg.rows);

	Mat M = getPerspectiveTransform(src_corner, dst_corner);
	warpPerspective(src, resultImg, M, resultImg.size(), INTER_LINEAR);
	//resultImg.resize(800,1200);
	//imshow("result Image", resultImg);
	//waitKey(0);
	imwrite("test.bmp", resultImg);
	imwrite(rotate_save_path.c_str(), resultImg);
}

vector<Area_point> get_diagonal(vector<Area_point>area)
{
	int x_min = area[0].x;
	int x_max = 0;
	int y_min = area[0].y;
	int y_max = 0;
	for (int i = 0; i < area.size(); i++)
	{
		if (area[i].x > x_max)
			x_max = area[i].x;
		if (area[i].x < x_min)
			x_min = area[i].x;
		if (area[i].y > y_max)
			y_max = area[i].y;
		if (area[i].y < y_min)
			y_min = area[i].y;
	}
	vector<Area_point>t;
	t.push_back(Area_point(x_min, y_min));
	t.push_back(Area_point(x_max, y_max));
	return t;
}

vector<Area_point> get_diagonal_of_cluster(vector<vector<Area_point>> cluster)
{
	int min_x = get_diagonal(cluster[0])[0].x;
	int min_y = get_diagonal(cluster[0])[0].y;
	int max_x = 0;
	int max_y = 0;
	for (int i = 0; i < cluster.size(); i++)
	{
		if (get_diagonal(cluster[i])[1].x > max_x)
			max_x = get_diagonal(cluster[i])[1].x;
		if (get_diagonal(cluster[i])[0].x < min_x)
			min_x = get_diagonal(cluster[i])[0].x;
		if (get_diagonal(cluster[i])[1].y > max_y)
			max_y = get_diagonal(cluster[i])[1].y;
		if (get_diagonal(cluster[i])[0].y < min_y)
			min_y = get_diagonal(cluster[i])[0].y;
	}
	vector<Area_point>t;
	t.push_back(Area_point(min_x, min_y));
	t.push_back(Area_point(max_x, max_y));
	return t;
}

vector<Area_point>middle(vector<vector<Area_point>> link_area)
{
	vector<Area_point>result;
	for (int i = 0; i < link_area.size(); i++)
	{
		vector<Area_point> diagonal = get_diagonal(link_area[i]);
		int x = (diagonal[0].x + diagonal[1].x) / 2;
		int y = (diagonal[0].y + diagonal[1].y) / 2;
		result.push_back(Area_point(x, y));
	}
	return result;
}

vector<vector<vector<Area_point>>> Cluster(vector<vector<Area_point>> link_area)
{
	vector<Area_point>middle_points = middle(link_area);
	vector<vector<Area_point>>temp(link_area);
	vector<vector<vector<Area_point>>> clusters;
	vector<vector<Area_point>>c;
	int base = middle_points[0].y;//��һ��������ĵ�������꣬������
	c.push_back(link_area[0]);//�ѵ�һ��������һ���ۼ���
	//������ͨ���Ǵ��ϵ���ȡ�ģ�������һ�е���ͨ������һ�������ڵ�
	for (int i = 1; i < link_area.size(); i++)
	{
		if (abs(middle_points[i].y - base) < 47)
		{
			base = (base * c.size() + middle_points[i].y) / (c.size() + 1);
			c.push_back(link_area[i]);
		}
		else
		{
			if (c.size() >= 2)
				clusters.push_back(c);
			c.clear();
			c.push_back(link_area[i]);
			base = middle_points[i].y;
		}
	}
	clusters.push_back(c);
	return clusters;
}

void CutImage::DrawClusters(vector<vector<vector<Area_point>>> clusters)
{
	unsigned char blue[3] = { 0, 0, 255 };
	for (int i = 0; i < clusters.size(); i++)
	{
		vector<Area_point>rec = get_diagonal_of_cluster(clusters[i]);
		cuted.draw_rectangle(rec[0].x - 3, rec[0].y - 3, rec[1].x + 3, rec[1].y + 3, blue, 1, ~0U);
	}
	//delate.display();
}

void CutImage::Cut()
{
	rotate.load(rotate_save_path.c_str());
	cuted.load(rotate_save_path.c_str());
	otsu = CImg<unsigned char>(rotate._width, rotate._height, 1, 1);
	delate = CImg<unsigned char>(rotate._width, rotate._height, 1, 1);
	Otsu();
	Delate();
	get_link_area();
	vector<vector<vector<Area_point>>> clusters = Cluster(link_area);
	DrawClusters(clusters);
	cuted.save(cut_save_path.c_str());
}
