#include "Hough.h"
#include "CANNY.h"
#include <cmath>
#include <algorithm>
#include <functional>

#define PI 3.141592653
#define theta 360
#define range 60

Hough::Hough(string input,float sigma) {

	for (int i = 0; i < theta; i++) {
		setSin.push_back(sin(2 * PI * i / theta));
		setCos.push_back(cos(2 * PI * i / theta));
	}

	I4.load(input.c_str());
	CCannyEdgeDetection cced;
	cced.OpenImage(input.c_str());
	cced.Src.resize(600, 800);
	cced.Canny(Iedge, 70, 100, 1.2);
	cced.canny_line(Iedge, 20);
	//Iedge.display();
	Iedge = cced.delete_line(Iedge);
	//Iedge.display();
		//Iedge = cced.canny_line(Iedge, 10);
	for (int i = 0; i < theta; i++) {
		setSin.push_back(sin(2 * PI * i / theta));
		setCos.push_back(cos(2 * PI * i / theta));
	}
	houghLinesTransform(Iedge); // ����ֱ�߱任
	findLine(); // ����ֱ�߼��
	I4.resize(600, 800);
	drawLine(); // ������任�����ı�Ե
	drawPoint(); // ������任�����Ľǵ�
}
/*����ֱ�߱任*/
void Hough::houghLinesTransform(CImg<float>& img) {
	int width = img._width, height = img._height, n;
	//����һ������ռ����Χ,n*360
	n = sqrt(pow(width / 2, 2) + pow(height / 2, 2));

	houghImage = CImg<float>(n, theta);
	houghImage.fill(0);

	cimg_forXY(img, x, y) {
		int value = img(x, y), p = 0;
		if (value != 0) {
			int x0 = x - width / 2, y0 = height / 2 - y;
			for (int i = 0; i < theta; i++) {
				//����ͶƱ
				p = x0 * setCos[i] + y0 * setSin[i];
				if (p >= 0 && p < n) {
					houghImage(p, i)++;
				}
			}
		}
	}
	//houghImage.display();
}

void Hough::findLine() {

	int width = houghImage._width, height = houghImage._height, size = range;
	int max;
	for (int i = 0; i < height; i += size / 2) {
		for (int j = 0; j < width; j += size / 2) {
			max = getCorssValue(houghImage, size, i, j);
			for (int y = i; y < i + size; ++y) {
				for (int x = j; x < j + size; ++x) {
					if (houghImage._atXY(x, y) < max) {
						houghImage._atXY(x, y) = 0;
					}
				}
			}
		}
	}
	//������ͼ�������в�Ϊ0�ĵ��������
	cimg_forXY(houghImage, x, y) {
		if (houghImage(x, y) != 0) {
			lines.push_back(make_pair(y, x));
			lineWeight.push_back(houghImage(x, y));
		}
	}
}

int Hough::getCorssValue(CImg<float>& img, int& size, int& y, int& x) {
	int width = (x + size > img._width) ? img._width : x + size;
	int height = (y + size > img._height) ? img._height : y + size;
	int max = 0;
	for (int j = x; j < width; j++) {
		for (int i = y; i < height; i++) {
			max = (img(j, i) > max) ? img(j, i) : max;
		}
	}
	return max;
}


void Hough::drawLine() {
	int width = Iedge._width, height = Iedge._height, n;
	n = sqrt(pow(width / 2, 2) + pow(height / 2, 2));

	edge = CImg<float>(width, height, 1, 1, 0);
	sortLineWeight = lineWeight;
	sort(sortLineWeight.begin(), sortLineWeight.end(), greater<int>()); // ���ۼӾ���Ӵ�С��������

	vector<pair<int, int>> result; // ����ۼ�ֵ���ı�Եֱ�߶�Ӧб�ʺͽؾ�
	int temp_index = 0;
	for (int i = 0; i < sortLineWeight.size(); i++) {
		if (sortLineWeight[i] > 100)
		{
			int weight = sortLineWeight[i], index;
			vector<int>::iterator iter = find(lineWeight.begin(), lineWeight.end(), weight);
			index = iter - lineWeight.begin();
			if (index == temp_index)
				continue;
			cout << "xcos(" << lines[index].second << ")+ysin(" << lines[index].second << ") = " << lines[index].first << endl;
			result.push_back(lines[index]);
			temp_index = index;
		}
		else
			break;
	}
	for (int i = 0; i < result.size(); i++) {
		int t = result[i].first, p = result[i].second;
		/*����t��p���б�ʺͽؾ�*/
		cimg_forXY(edge, x, y) {
			int x0 = x - width / 2, y0 = height / 2 - y;
			if (p == (int)(x0 * setCos[t] + y0 * setSin[t])) {
				//�ҽ���
				edge(x, y) += 1;
				//I4(x, y, 0, 2) = 255;
			}
		}
	}
	//I4.display();
}


void Hough::filter_corss_point()
{
	vector<pair<int, int>> new_corss_point;
	for (int i = 0; i < corss_point.size(); i++)
	{
		if (corss_point[i].second > 150 && corss_point[i].second < 650)
			new_corss_point.push_back(corss_point[i]);
	}
	corss_point = new_corss_point;
}

void Hough::drawPoint() {
	
	unsigned char red[3] = { 255, 0, 0 };
	//edge.display();
	int width = I4._width;
	int height = I4._height;
	I4.resize(600, 800);
	for (int y = 1; y < I4._height - 1; y++) {
		for (int x = 1; x < I4._width - 1; x++) {
			int arr[9];
			arr[0] = edge(x, y);
			arr[1] = edge(x + 1, y);
			arr[2] = edge(x, y + 1);
			arr[3] = edge(x + 1, y + 1);
			arr[4] = edge(x - 1, y);
			arr[5] = edge(x, y - 1);
			arr[6] = edge(x - 1, y - 1);
			arr[7] = edge(x + 1, y - 1);
			arr[8] = edge(x - 1, y + 1);
			if ((arr[0] >= 2 && arr[1] < 2 && arr[2] < 2 && arr[3] < 2 && arr[4] < 2 && arr[5] < 2 && arr[6] < 2 && arr[7] < 2 && arr[8] < 2)|| arr[0] == 3) {
				corss_point.push_back(make_pair(x, y));//�õ����еĽ�������
				//I4.draw_circle(x, y, 5, red);
			}
		}
	}
	I4.resize(width, height);
	//I4.display();
}
