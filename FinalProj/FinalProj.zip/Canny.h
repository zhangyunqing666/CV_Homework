#pragma once
/*
 * CannyEdgeDetection.h
 *
*/
#include<queue>
#include<stack>
#ifndef __CANNY_255_DETECTION_H__
#define __CANNY_255_DETECTION_H__

#include <vector>
#include "CImg.h"
#include<iostream>
using namespace cimg_library;
using namespace std;
//----canny��Ե���-----------
class CCannyEdgeDetection
{

public:
	CImg<unsigned char> Src;
public:
	string name;
public:
	//--------ͼƬ����---------------
	void display_Img(int*data, int width, int height);
	int OpenImage(const char* filename);
	int Canny(CImg<float> &Dst, double low_thresh, double high_thresh, float sigma);
	CImg<unsigned char> canny_line(CImg<unsigned char> picture, int distance)
	{
		int rows = picture._width;
		int cols = picture._height;
		CImg<unsigned char> final_result = picture;

		for (int r = 2; r < rows - 2; r++) {
			for (int c = 2; c < cols - 2; c++) {
				int count = 0;
				if ((int)final_result(r, c) == 255) {
					for (int rr = -1; rr < 2; rr++) {
						for (int cc = -1; cc < 2; cc++) {
							if (rr != 0 && cc != 0
								&& (int)final_result(r + rr, c + cc) == 255) {
								count++;
							}
						}
					}

					/* Search it's 16 neightbor */
					if (count == 1) {
						for (int rr = -2; rr < 3; rr++) {
							for (int cc = -2; cc < 3; cc++) {
								if (!(rr < 2 && rr > -2 && cc < 2 && cc > -2)
									&& (int)final_result(r + rr, c + cc) == 255) {
									final_result(r + rr / 2, c + cc / 2, 0) = 255;
									final_result(r + rr / 2, c + cc / 2, 1) = 255;
									final_result(r + rr / 2, c + cc / 2, 2) = 255;
								}
							}
						}
					}
				}
			}
		}

		/* Show the image after edge linking. */
		//final_result.display("Link result");
		return final_result;
	}
	CImg<unsigned char> delete_line(CImg<unsigned char> picture)
	{
		int rows = picture._width;
		int cols = picture._height;
		int dx[8] = { 1,1,0,-1,-1,-1,0,1 },
			dy[8] = { 0,1,1,1,0,-1,-1,-1 };
		int length = 0;
		int pos = 0;
		CImg<unsigned char> final_result = picture;
		queue<pair<int, int>> Queue;
		vector<vector<bool>> isVisited(rows, vector<bool>(cols, false));
		vector<stack<pair<int, int>>> Stack(10000, stack<pair<int, int>>());
		for (int r = 0; r < rows; r++) {
			for (int c = 0; c < cols; c++) {
				if ((int)final_result(r, c) == 0) {
					isVisited[r][c] = true;
				}
			}
		}

		//�����������
		for (int r = 0; r < rows; r++) {
			for (int c = 0; c < cols; c++) {
				length = 0;
				if (!isVisited[r][c]) {
					Queue.push(make_pair(r, c));
					Stack[pos].push(make_pair(r, c));
					while (!Queue.empty()) {
						int Row = Queue.front().first;
						int Col = Queue.front().second;
						if (!isVisited[Row][Col]) {
							isVisited[Row][Col] = true;
							length++;
							Stack[pos].push(make_pair(Row, Col));
							for (int i = 0; i < 8; i++) {
								if (Row + dx[i] >= 0 && Row + dx[i] < rows &&
									Col + dy[i] >= 0 && Col + dy[i] < cols &&
									!isVisited[Row + dx[i]][Col + dy[i]]) {
									Queue.push(make_pair(Row + dx[i], Col + dy[i]));
								}
							}
						}
						Queue.pop();
					}

					//ɾ������С��30������
					if (length < 30) {
						while (!Stack[pos].empty()) {
							int Row = Stack[pos].top().first;
							int Col = Stack[pos].top().second;
							final_result(Row, Col, 0) = 0;
							final_result(Row, Col, 1) = 0;
							final_result(Row, Col, 2) = 0;
							isVisited[Row][Col] = true;
							Stack[pos].pop();
						}
					}
					pos++;
				}
			}
		}
		return final_result;
	}
	CImg<unsigned char> Draw_line(CImg<unsigned char> tmp, int x, int y, int x1, int y1) {
		CImg <unsigned char> Img = tmp;
		int white[] = { 255,255,255 };
		Img.draw_line(x, y, x1, y1, white);
		return Img;
	}
};

#endif //__CANNY_255_DETECTION_H__