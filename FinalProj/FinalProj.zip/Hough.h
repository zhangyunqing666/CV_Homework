﻿
#ifndef HOUGH_H
#define HOUGH_H

#include <iostream>
#include <string>
#include <vector>
#include "CImg.h"
#include<opencv2/opencv.hpp>
#include <opencv2/core.hpp>                //Mat         核心库
#include <opencv2/imgcodecs.hpp>        //imread    读图片函数
#include <opencv2/highgui.hpp>            //namedWindow imshow waitKey    界面
#include <opencv2/imgproc.hpp>
using namespace cv;
using namespace std;
using namespace cimg_library;

class Hough {
public:
	Hough(string,float sigma);
	void houghLinesTransform(CImg<float>&);
	void findLine();
	int getCorssValue(CImg<float>&, int&, int&, int&);
	void drawLine();
	void filter_corss_point();
	void drawPoint();
	CImg<float> I4;
	vector<pair<int, int>> corss_point;
private:
	CImg<float> image;
	CImg<float> grayImage;
	CImg<float> Iedge;
	CImg<float> houghImage;
	vector<float> setSin;
	vector<float> setCos;
	vector<pair<int, int>> lines;
	vector<int> lineWeight;
	vector<int> sortLineWeight;
	CImg<float> edge;
};

#endif 