#pragma once
#include"Hough.h"
struct  Area_point
{
	int x;
	int y;
	Area_point(int x_, int y_)
	{
		x = x_;
		y = y_;
	}
};
class CutImage {
private:
	int threshold;
	int gray_level[256];
	string rotate_save_path;
	string cut_save_path;
	string filename;
	CImg<float>Src;
	CImg<unsigned char>rotate;
	CImg<unsigned char>cuted;
	vector<pair<int, int>> corss_point;
	CImg<unsigned char> otsu;
	CImg<unsigned char> delate;
	vector<Area_point>temp;
	vector<vector<Area_point>> link_area;
	void Otsu();
	void Delate();
	void get_link_area();
	void getGray();
	void findThreshold();
	void DrawClusters(vector<vector<vector<Area_point>>>clusters);
public:
	CutImage(string file,string rotate_card_save_path,string cut_card_save_path);
	void getImg();
	void Rotate();
	void Cut();
};